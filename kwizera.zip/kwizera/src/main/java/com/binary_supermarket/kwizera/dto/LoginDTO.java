package com.binary_supermarket.kwizera.dto;

public record LoginDTO(
        String email,
        String password
) {}

