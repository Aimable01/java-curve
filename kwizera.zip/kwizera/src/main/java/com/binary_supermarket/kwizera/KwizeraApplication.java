package com.binary_supermarket.kwizera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KwizeraApplication {

	public static void main(String[] args) {
		SpringApplication.run(KwizeraApplication.class, args);
	}

}
